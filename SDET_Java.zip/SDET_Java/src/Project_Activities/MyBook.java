package Project_Activities;
 
class MyBook extends Book{
	//Define abstract method
	    public void setTitle(String s) {
	        title = s;

	    }
 }
