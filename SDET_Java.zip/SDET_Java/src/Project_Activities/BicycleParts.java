package Project_Activities;

public interface BicycleParts {
	public int gears = 0;
    public int currentSpeed = 0;

}
